package com.example.artsearchapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends AppCompatActivity {

    // UI components
    private EditText editTextQuery;
    private Button buttonSearch;
    private TextView textViewTitle, textViewArtist;
    private ImageView imageViewArt;

    // Background thread executor and main thread handler
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());

    // Updated servlet URL pointing to your dynamic API endpoint.
    // When running on an emulator, 10.0.2.2 maps to localhost.
    private final String servletUrl = "http://10.0.2.2:8080/Project4Task2/api/artworks";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link UI components
        editTextQuery = findViewById(R.id.editTextQuery);
        buttonSearch = findViewById(R.id.buttonSearch);
        textViewTitle = findViewById(R.id.textViewTitle);
        textViewArtist = findViewById(R.id.textViewArtist);
        imageViewArt = findViewById(R.id.imageViewArt);

        // Set up the search button click listener
        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String query = editTextQuery.getText().toString().trim();

                // Input validation
                if (query.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a search term", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Initiate background search with the user query
                searchArtwork(query);
            }
        });
    }

    /**
     * Sends the search query to the servlet and updates the UI with the results.
     * This method parses the returned JSON which contains an "artworks" array.
     */
    private void searchArtwork(String query) {
        executor.execute(() -> {
            try {
                // Build the URL including the query parameter
                URL url = new URL(servletUrl + "?query=" + query);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);  // Connection timeout
                connection.setReadTimeout(5000);     // Read timeout

                // Check for a successful response
                int responseCode = connection.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new Exception("Server returned error: " + responseCode);
                }

                // Read the response stream
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder responseBuilder = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    responseBuilder.append(line);
                }
                in.close();

                // Parse the JSON response
                JSONObject json = new JSONObject(responseBuilder.toString());
                // The response is structured as: { "artworks": [ { ... }, ... ] }
                JSONArray artworks = json.optJSONArray("artworks");

                // Default values if no artwork is found
                String title = "N/A";
                String artist = "Unknown";
                String imageUrl = "";

                if (artworks != null && artworks.length() > 0) {
                    // Use the first artwork from the array
                    JSONObject firstArtwork = artworks.getJSONObject(0);
                    title = firstArtwork.optString("title", "N/A");
                    artist = firstArtwork.optString("artist_display", "Unknown");
                    imageUrl = firstArtwork.optString("imageUrl", "");
                }

                // Post updates back to the main thread
                final String finalTitle = title;
                final String finalArtist = artist;
                final String finalImageUrl = imageUrl;
                handler.post(() -> {
                    textViewTitle.setText("Title: " + finalTitle);
                    textViewArtist.setText("Artist: " + finalArtist);

                    if (!finalImageUrl.isEmpty()) {
                        // Load the artwork image using Glide
                        Glide.with(MainActivity.this)
                                .load(finalImageUrl)
                                .into(imageViewArt);
                    } else {
                        // Set a fallback image if no image URL is provided
                        imageViewArt.setImageResource(R.drawable.ic_launcher_foreground);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> {
                    Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    textViewTitle.setText("Title: N/A");
                    textViewArtist.setText("Artist: Unknown");
                    imageViewArt.setImageResource(R.drawable.ic_launcher_foreground);
                });
            }
        });
    }
}
